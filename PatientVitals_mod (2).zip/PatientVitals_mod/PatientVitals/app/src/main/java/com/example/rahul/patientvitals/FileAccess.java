package com.example.rahul.patientvitals;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by rahul on 17/10/14.
 */
public class FileAccess {

    private static BufferedWriter buf;
    private static File logFile;

    public FileAccess()
    {
        if (logFile==null)
        {
            logFile = new File("analytics");

        }
        if (!logFile.exists())
        {
            try {
                logFile.createNewFile();


            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    public FileAccess(String Flname)
    {
        logFile = new File(Flname);
        if (!logFile.exists())
        {
            try {
                logFile.createNewFile();


            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
   /* public FileAccess(int Flname)
    {
        logFile = new File("android.resource://com.slideshow.project/"+Flname);
        if (!logFile.exists())
        {
                logFile=null;
        }

    }*/

    public void writeText(String text){
        try
        {
            buf = new BufferedWriter(new FileWriter(logFile, true));
            buf.append(text);
            buf.newLine();
            buf.close();

        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    /* public void readNotes(Context ctx){
         try
         {
             DbConnect noteStore = new DbConnect(ctx);
             BufferedReader br = new BufferedReader(new FileReader(logFile));
             String line;
             int cnt=0;
             while ((line = br.readLine()) != null) {
                 noteStore.open();
                *//* Cursor textData =noteStore.fetchNote(cnt);
                if(textData.getCount()!=0){
                    store.updateNote(position,((EditText)rl.findViewWithTag("notepad")).getText().toString());
                }else{*//*
                noteStore.updateNote(cnt,line);
              //  }
                 cnt++;

            }
            br.close();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }*/
    public void closeFile(){
        try{
            buf.close();
        }
        catch (IOException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}

